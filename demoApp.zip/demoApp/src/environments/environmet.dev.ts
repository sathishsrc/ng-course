export const environment = {
  production: false,
  envName: 'dev',
  api: 'http://api-dev'
};